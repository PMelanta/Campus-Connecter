﻿/* Croatian language file for the DHTML Calendar version 0.9.2 ਍⨀ 䄀甀琀栀漀爀 䬀爀甀渀漀猀氀愀瘀 娀甀戀爀椀渀椀挀 㰀欀爀甀渀漀猀氀愀瘀⸀稀甀戀爀椀渀椀挀䀀瘀椀瀀⸀栀爀㸀Ⰰ 䨀甀渀攀 ㈀　　㌀⸀ഀഀ
* Feel free to use this script under the terms of the GNU Lesser General਍⨀ 倀甀戀氀椀挀 䰀椀挀攀渀猀攀Ⰰ 愀猀 氀漀渀最 愀猀 礀漀甀 搀漀 渀漀琀 爀攀洀漀瘀攀 漀爀 愀氀琀攀爀 琀栀椀猀 渀漀琀椀挀攀⸀ഀഀ
*/਍䌀愀氀攀渀搀愀爀⸀开䐀一 㴀 渀攀眀 䄀爀爀愀礀ഀഀ
("Nedjelja",਍ ∀倀漀渀攀搀樀攀氀樀愀欀∀Ⰰഀഀ
 "Utorak",਍ ∀匀爀椀樀攀搀愀∀Ⰰഀഀ
 "Četvrtak",਍ ∀倀攀琀愀欀∀Ⰰഀഀ
 "Subota",਍ ∀一攀搀樀攀氀樀愀∀⤀㬀ഀഀ
Calendar._MN = new Array਍⠀∀匀椀樀攀ഀ愁渀樀∀Ⰰഀഀ
 "Veljača",਍ ∀伀縀甁樀愀欀∀Ⰰഀഀ
 "Travanj",਍ ∀匀瘀椀戀愀渀樀∀Ⰰഀഀ
 "Lipanj",਍ ∀匀爀瀀愀渀樀∀Ⰰഀഀ
 "Kolovoz",਍ ∀刀甀樀愀渀∀Ⰰഀഀ
 "Listopad",਍ ∀匀琀甀搀攀渀椀∀Ⰰഀഀ
 "Prosinac");਍ഀഀ
// tooltips਍䌀愀氀攀渀搀愀爀⸀开吀吀 㴀 笀紀㬀ഀഀ
Calendar._TT["TOGGLE"] = "Promjeni dan s kojim počinje tjedan";਍䌀愀氀攀渀搀愀爀⸀开吀吀嬀∀倀刀䔀嘀开夀䔀䄀刀∀崀 㴀 ∀倀爀攀琀栀漀搀渀愀 最漀搀椀渀愀 ⠀搀甀最椀 瀀爀椀琀椀猀愀欀 稀愀 洀攀渀椀⤀∀㬀ഀഀ
Calendar._TT["PREV_MONTH"] = "Prethodni mjesec (dugi pritisak za meni)";਍䌀愀氀攀渀搀愀爀⸀开吀吀嬀∀䜀伀开吀伀䐀䄀夀∀崀 㴀 ∀䤀搀椀 渀愀 琀攀欀甀܀椁 搀愀渀∀㬀ഀഀ
Calendar._TT["NEXT_MONTH"] = "Slijedeći mjesec (dugi pritisak za meni)";਍䌀愀氀攀渀搀愀爀⸀开吀吀嬀∀一䔀堀吀开夀䔀䄀刀∀崀 㴀 ∀匀氀椀樀攀搀攀܀愁 最漀搀椀渀愀 ⠀搀甀最椀 瀀爀椀琀椀猀愀欀 稀愀 洀攀渀椀⤀∀㬀ഀഀ
Calendar._TT["SEL_DATE"] = "Izaberite datum";਍䌀愀氀攀渀搀愀爀⸀开吀吀嬀∀䐀刀䄀䜀开吀伀开䴀伀嘀䔀∀崀 㴀 ∀倀爀椀琀椀猀渀椀 椀 瀀漀瘀甀挀椀 稀愀 瀀爀漀洀樀攀渀甀 瀀漀稀椀挀椀樀攀∀㬀ഀഀ
Calendar._TT["PART_TODAY"] = " (today)";਍䌀愀氀攀渀搀愀爀⸀开吀吀嬀∀䴀伀一开䘀䤀刀匀吀∀崀 㴀 ∀倀爀椀欀愀縀椁 瀀漀渀攀搀樀攀氀樀愀欀 欀愀漀 瀀爀瘀椀 搀愀渀∀㬀ഀഀ
Calendar._TT["SUN_FIRST"] = "Prikaži nedjelju kao prvi dan";਍䌀愀氀攀渀搀愀爀⸀开吀吀嬀∀䌀䰀伀匀䔀∀崀 㴀 ∀娀愀琀瘀漀爀椀∀㬀ഀഀ
Calendar._TT["TODAY"] = "Danas";਍ഀഀ
// date formats਍䌀愀氀攀渀搀愀爀⸀开吀吀嬀∀䐀䔀䘀开䐀䄀吀䔀开䘀伀刀䴀䄀吀∀崀 㴀 ∀搀搀ⴀ洀洀ⴀ礀∀㬀ഀഀ
Calendar._TT["TT_DATE_FORMAT"] = "DD, dd.mm.y";਍ഀഀ
Calendar._TT["WK"] = "Tje";