package cc.base;

class UConfigException extends UBaseException {

    UConfigException(String msg, Exception cause) {
        super(msg, cause);
    }
}
