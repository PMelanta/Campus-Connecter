package cc.base;

public class UAuthenticationException extends UBaseException {

    public UAuthenticationException(String msg, Exception cause) {
        super(msg, cause);
    }
}
