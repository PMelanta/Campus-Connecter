package cc.base;

public class UDBAccessException extends UBaseException {

    public UDBAccessException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
