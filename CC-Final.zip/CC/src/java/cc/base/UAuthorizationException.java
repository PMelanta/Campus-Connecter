package cc.base;

public class UAuthorizationException extends UBaseException {

    public UAuthorizationException (String msg, Throwable cause) {
        super(msg, cause);
    }
}
